﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Services.Strategy
{
    /// <summary>
    /// Interfaz que implementa los distintos tipos de cotizacion.
    /// </summary>
   public interface IStrategy
    {
       /// <summary>
       /// Obtiene la cotizacion de moneda.
       /// </summary>
       /// <returns></returns>
        double Cotizacion(Uri uri);
    }
}