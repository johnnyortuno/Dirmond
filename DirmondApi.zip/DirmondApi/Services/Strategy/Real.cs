﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Services.Strategy
{
    public class Real : IStrategy
    {
        /// <summary>
        /// Obtiene la cotizacion de la moneda Real.
        /// </summary>
        /// <returns>El valor de la cotizacion</returns>
        public double Cotizacion(Uri uri)
        {
            return utils.GetValorMoneda(utils.GetCotizacion(uri));
        }
    }
}