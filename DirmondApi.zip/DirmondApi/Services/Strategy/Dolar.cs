﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;


namespace Services.Strategy
{
    public class Dolar : IStrategy
    {
        /// <summary>
        /// Obtiene la cotizacion de la moneda Dolar Americana.
        /// </summary>
        /// <returns>El valor de la cotizacion</returns>
        public double Cotizacion(Uri uri)
        {

            return utils.GetValorMoneda(utils.GetCotizacion(uri));
        }
    }
}