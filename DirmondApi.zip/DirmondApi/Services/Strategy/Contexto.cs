﻿
using Services.Strategy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Services
{
     class Contexto
    {
        IStrategy strategy;

       /// <summary>
       /// 
       /// </summary>
       /// <param name="strategy"></param>
        public Contexto(IStrategy strategy)
        {
            this.strategy = strategy;
        }

         /// <summary>
         /// Obtiene las cotizaciones.
         /// </summary>
         /// <returns></returns>
        public double ObtenerCotizacion(Uri uri)
        {
           return strategy.Cotizacion(uri);
        }
    }
}