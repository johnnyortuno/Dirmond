﻿using Services.DTO;
using Services.Strategy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
   public class ServiceCotizacion
    {
       public Cotizacion GetCotizacion(string Moneda , string key)
       {
           Contexto context;
           double resultado=0;
           Uri uri;
           switch (Moneda.ToUpper())
           {
               case "DOLAR":
                   uri = new Uri("https://api.cambio.today/v1/full/USD/json?Key=" + key);
                   context = new Contexto(new Dolar());
                   resultado=context.ObtenerCotizacion(uri);
                   break;
               case "REAL":
                   uri = new Uri("https://api.cambio.today/v1/full/BRL/json?Key=" + key);
                   context = new Contexto(new Real());
                   resultado=context.ObtenerCotizacion(uri);
                   break;
               case "EURO":
                   uri = new Uri("https://api.cambio.today/v1/full/EUR/json?Key=" + key);
                   context = new Contexto(new Euro());
                   resultado=context.ObtenerCotizacion(uri);
                   break;

               default:
                   resultado = 0;
                   Moneda = "La moneda esta fuera de la cotizacion";
                   break;
           }
           List<Cotizacion> coti = new List<Cotizacion>();
           coti.Add(new Cotizacion { moneda = Moneda, precio = resultado });
           return coti.FirstOrDefault();  
       }
    }
}
