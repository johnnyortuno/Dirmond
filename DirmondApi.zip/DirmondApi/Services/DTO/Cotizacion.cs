﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.DTO
{
    public class Cotizacion
    {
        /// <summary>
        /// Nombre del tipo de moneda.
        /// </summary>
        public string moneda { get; set; }

        /// <summary>
        /// precio de la moneda actual.
        /// </summary>
        public double precio { get; set; }
    }
}

