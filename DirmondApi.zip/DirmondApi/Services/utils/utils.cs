﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;

namespace Services
{
    public static class utils
    {
        public static string GetCotizacion(Uri uri)
        {
            String result = String.Empty;
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(uri);
            request.Method = "GET";
           
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                Stream dataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                result = reader.ReadToEnd();
                reader.Close();
                dataStream.Close();
            }
            return result;
        }
        public static double GetValorMoneda(string resultado)
        {
            double precio = 0;
            dynamic dynJson = JsonConvert.DeserializeObject(resultado);
            if (dynJson != null)
            {
                foreach (var item in dynJson.result.conversion)
                {
                    if (item.to == "ARS")
                    {
                        precio = item.rate;
                        break;
                    }
                }
            }

            return precio;
        }


    }
}