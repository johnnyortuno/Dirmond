﻿"use strict"

var Url = $("#Url").val();

$(function () {
    debugger;
    $("#grid").jqGrid
    ({
        url: Url,
        datatype: 'json',
        postData: {
            Moneda: function () { return $('#selMoneda').val(); }
        },
        mtype: 'Get',
        colModel: [
        { name: 'moneda', index: 'moneda' },
        { name: "precio", index: 'precio' }

        ],
        height: '100%',
        viewrecords: true,
        caption: 'Cotizacion Moneda',
        emptyrecords: 'No records',
        rowNum: 10,

        pager: jQuery('#pager'),
        rowList: [10, 20, 30, 40],

        jsonReader:
        {
            root: "rows",
            page: "page",
            total: "total",
            records: "records",
            repeatitems: false,
            Id: "0"
        },
        autowidth: true,
    }).navGrid('#pager',
        {
            edit: false,
            add: false,
            del: false,
            search: false,
            refresh: true,

        });
});


var refreshgrid = setInterval(function () {
    $('#grid').trigger("reloadGrid");
}, 5000);