﻿using Newtonsoft.Json;
using Services;
using Services.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Remoting.Contexts;
using System.Web.Configuration;
using System.Web.Http;

namespace ApiHelpers.Controllers
{
    public class CotizacionController : ApiController
    {
        private string key = WebConfigurationManager.AppSettings["key"].ToString();
       

        [Route("Cotizacion/{Moneda}")]
        [HttpGet]
        public Cotizacion Cotizacion(string Moneda)
        {
            ServiceCotizacion service = null;
            try
            {
              service = new ServiceCotizacion();
              return  service.GetCotizacion(Moneda, key);
            }
            catch (Exception)
            {

                return null;
            }
            finally
            {
                service = null;
            }
        }

    }
    
}
