﻿using Services;
using Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ApiHelpers.Controllers
{
    public class MonedaController : Controller
    {
         private string key = System.Web.Configuration.WebConfigurationManager.AppSettings["key"].ToString();
        // GET: Moneda
        public ActionResult Index()
        {
            return View();
        }
        public JsonResult GetMoneda(bool _search, string nd, int rows, int page, string sidx, string sord, string Moneda)
        {
            ServiceCotizacion service = null;
            Cotizacion cotizacion = null;
            List<Cotizacion> lCotizacion = null;
            try
            {
                service = new ServiceCotizacion();
                cotizacion = service.GetCotizacion(Moneda, key);
                lCotizacion = new List<Cotizacion>();
                lCotizacion.Add(cotizacion);
                var jsonData = new
                {
                    total = lCotizacion.Count,
                    page,
                    records = lCotizacion.Count,
                    rows = lCotizacion
                };
                return Json(jsonData, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {
                
                throw;
            }
            finally
            {
                service = null;
                cotizacion = null;
                lCotizacion = null;
            }
          
         
        }
    }
    
}